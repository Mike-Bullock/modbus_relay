# Sealevel PoE Relay Home Assistant custom integration

This custom integration adds switch entities for relay boards that:

- answer a UDP discovery broadcast on port `1092`
- accept RTU-style Modbus frames over a raw TCP socket on port `4196`

It is based on the reverse-engineered discovery/control workflow in:

- https://github.com/Mike-Bullock/modbus_relay

## Install

Copy this folder into your Home Assistant config directory:

```text
config/custom_components/sealevel_poe_relay/
```

Then restart Home Assistant.

## Add the integration

Go to:

**Settings -> Devices & Services -> Add Integration -> Sealevel PoE Relay**

You can either:

- Scan the LAN with the UDP discovery packet
- Enter the relay IP manually

## Notes

- Default relay count is `8`; change it during setup or later in Options.
- Default TCP port is `4196`.
- Default Modbus unit ID is `1`.
- The integration polls relay states using Modbus function `0x01` (read coils).
- Relay writes use function `0x05` (write single coil).

## Caveat

The discovery packet and some response parsing are reverse-engineered, not vendor-documented. If your hardware speaks plain Modbus TCP on port `502` instead, use Home Assistant's built-in Modbus integration instead of this custom component.
