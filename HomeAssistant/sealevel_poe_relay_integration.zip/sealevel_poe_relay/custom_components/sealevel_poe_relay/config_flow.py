"""Config flow for Sealevel PoE Relay."""
from __future__ import annotations

from collections.abc import Mapping
import logging
from typing import Any

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import callback
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers import selector

from .const import (
    CONF_DISCOVERY_PORT,
    CONF_HOST,
    CONF_NAME,
    CONF_POLL_INTERVAL,
    CONF_RELAY_COUNT,
    CONF_SCAN_TIMEOUT,
    CONF_TCP_PORT,
    CONF_UNIT_ID,
    DEFAULT_DISCOVERY_PORT,
    DEFAULT_NAME,
    DEFAULT_POLL_INTERVAL,
    DEFAULT_RELAY_COUNT,
    DEFAULT_SCAN_TIMEOUT,
    DEFAULT_TCP_PORT,
    DEFAULT_UNIT_ID,
    DOMAIN,
    MAX_RELAYS,
)
from .discovery import DiscoveredRelay, async_discover_relays

_LOGGER = logging.getLogger(__name__)


class SealevelPoERelayConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for the relay integration."""

    VERSION = 1

    def __init__(self) -> None:
        self._discovered: list[DiscoveredRelay] = []
        self._user_input: dict[str, Any] = {}

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        if user_input is not None:
            if user_input["method"] == "scan":
                return await self.async_step_scan()
            return await self.async_step_manual()

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required("method", default="scan"): selector.SelectSelector(
                        selector.SelectSelectorConfig(
                            options=[
                                selector.SelectOptionDict(value="scan", label="Scan network"),
                                selector.SelectOptionDict(value="manual", label="Enter IP manually"),
                            ],
                            mode=selector.SelectSelectorMode.DROPDOWN,
                        )
                    )
                }
            ),
        )

    async def async_step_scan(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            self._user_input.update(user_input)
            self._discovered = await async_discover_relays(
                timeout=user_input[CONF_SCAN_TIMEOUT],
                discovery_port=user_input[CONF_DISCOVERY_PORT],
            )
            if not self._discovered:
                errors["base"] = "no_devices_found"
            else:
                return await self.async_step_pick_device()

        return self.async_show_form(
            step_id="scan",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_SCAN_TIMEOUT, default=DEFAULT_SCAN_TIMEOUT): vol.Coerce(float),
                    vol.Optional(CONF_DISCOVERY_PORT, default=DEFAULT_DISCOVERY_PORT): vol.Coerce(int),
                }
            ),
            errors=errors,
        )

    async def async_step_pick_device(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        if user_input is not None:
            host = user_input[CONF_HOST]
            self._user_input[CONF_HOST] = host
            return await self.async_step_finish()

        options = [
            selector.SelectOptionDict(value=device.host, label=device.title)
            for device in self._discovered
        ]
        return self.async_show_form(
            step_id="pick_device",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_HOST): selector.SelectSelector(
                        selector.SelectSelectorConfig(options=options, mode=selector.SelectSelectorMode.DROPDOWN)
                    )
                }
            ),
        )

    async def async_step_manual(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            self._user_input.update(user_input)
            return await self.async_step_finish()

        return self.async_show_form(
            step_id="manual",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_HOST): str,
                }
            ),
            errors=errors,
        )

    async def async_step_finish(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            combined = {**self._user_input, **user_input}
            await self.async_set_unique_id(combined[CONF_HOST])
            self._abort_if_unique_id_configured()

            title = combined[CONF_NAME]
            return self.async_create_entry(
                title=title,
                data={
                    CONF_HOST: combined[CONF_HOST],
                    CONF_NAME: title,
                    CONF_RELAY_COUNT: combined[CONF_RELAY_COUNT],
                    CONF_TCP_PORT: combined[CONF_TCP_PORT],
                    CONF_UNIT_ID: combined[CONF_UNIT_ID],
                    CONF_POLL_INTERVAL: combined[CONF_POLL_INTERVAL],
                },
            )

        return self.async_show_form(
            step_id="finish",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_NAME, default=DEFAULT_NAME): str,
                    vol.Optional(CONF_RELAY_COUNT, default=DEFAULT_RELAY_COUNT): vol.All(vol.Coerce(int), vol.Range(min=1, max=MAX_RELAYS)),
                    vol.Optional(CONF_TCP_PORT, default=DEFAULT_TCP_PORT): vol.Coerce(int),
                    vol.Optional(CONF_UNIT_ID, default=DEFAULT_UNIT_ID): vol.All(vol.Coerce(int), vol.Range(min=1, max=247)),
                    vol.Optional(CONF_POLL_INTERVAL, default=DEFAULT_POLL_INTERVAL): vol.All(vol.Coerce(int), vol.Range(min=5, max=3600)),
                }
            ),
            errors=errors,
        )

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: config_entries.ConfigEntry) -> config_entries.OptionsFlow:
        return SealevelPoERelayOptionsFlow(config_entry)


class SealevelPoERelayOptionsFlow(config_entries.OptionsFlow):
    """Handle options for the relay integration."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        self.config_entry = config_entry

    async def async_step_init(self, user_input: Mapping[str, Any] | None = None) -> FlowResult:
        if user_input is not None:
            return self.async_create_entry(title="", data=dict(user_input))

        return self.async_show_form(
            step_id="init",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_HOST, default=self.config_entry.options.get(CONF_HOST, self.config_entry.data[CONF_HOST])): str,
                    vol.Optional(CONF_RELAY_COUNT, default=self.config_entry.options.get(CONF_RELAY_COUNT, self.config_entry.data[CONF_RELAY_COUNT])): vol.All(vol.Coerce(int), vol.Range(min=1, max=MAX_RELAYS)),
                    vol.Optional(CONF_POLL_INTERVAL, default=self.config_entry.options.get(CONF_POLL_INTERVAL, self.config_entry.data.get(CONF_POLL_INTERVAL, DEFAULT_POLL_INTERVAL))): vol.All(vol.Coerce(int), vol.Range(min=5, max=3600)),
                }
            ),
        )
