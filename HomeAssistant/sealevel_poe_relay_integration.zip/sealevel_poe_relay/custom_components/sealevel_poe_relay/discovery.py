"""UDP discovery for PoE relay boards."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import socket

from .const import DEFAULT_DISCOVERY_PORT, DEFAULT_SCAN_TIMEOUT, DISCOVERY_PAYLOAD


@dataclass(slots=True)
class DiscoveredRelay:
    """A discovered relay board."""

    host: str
    device_id: str | None = None

    @property
    def title(self) -> str:
        """Return a readable label."""
        if self.device_id:
            return f"{self.host} ({self.device_id})"
        return self.host


def extract_device_id(data: bytes) -> str | None:
    """Extract pseudo device id from the vendor reply.

    The upstream reverse-engineered script uses the bytes after the
    ASCII delimiter ``8888888888`` as a 6-byte identifier.
    """
    try:
        parts = data.decode("latin-1", errors="ignore").split("8888888888")
        if len(parts) < 2:
            return None
        raw = parts[1][:6].encode("latin-1", errors="ignore")
        if len(raw) != 6:
            return None
        return raw.hex().upper()
    except Exception:
        return None


async def async_discover_relays(
    timeout: float = DEFAULT_SCAN_TIMEOUT,
    discovery_port: int = DEFAULT_DISCOVERY_PORT,
) -> list[DiscoveredRelay]:
    """Broadcast a discovery packet and collect replies."""
    loop = asyncio.get_running_loop()
    results: dict[str, DiscoveredRelay] = {}

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setblocking(False)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.bind(("0.0.0.0", 0))

    try:
        await loop.sock_sendto(sock, DISCOVERY_PAYLOAD, ("255.255.255.255", discovery_port))

        deadline = loop.time() + timeout
        while loop.time() < deadline:
            try:
                data, addr = await asyncio.wait_for(
                    loop.sock_recvfrom(sock, 2048),
                    timeout=deadline - loop.time(),
                )
            except asyncio.TimeoutError:
                break

            host = addr[0]
            results[host] = DiscoveredRelay(
                host=host,
                device_id=extract_device_id(data),
            )
    finally:
        sock.close()

    return sorted(results.values(), key=lambda item: item.host)
