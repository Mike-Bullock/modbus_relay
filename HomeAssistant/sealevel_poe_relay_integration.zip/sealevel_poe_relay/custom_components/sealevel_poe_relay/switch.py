"""Switch platform for Sealevel PoE Relay."""
from __future__ import annotations

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import CONF_NAME, CONF_RELAY_COUNT, DOMAIN
from .coordinator import RelayCoordinator

PARALLEL_UPDATES = 0


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: RelayCoordinator = hass.data[DOMAIN][entry.entry_id]
    relay_count = entry.options.get(CONF_RELAY_COUNT, entry.data[CONF_RELAY_COUNT])
    async_add_entities(
        SealevelRelaySwitch(coordinator, entry, index) for index in range(relay_count)
    )


class SealevelRelaySwitch(CoordinatorEntity[RelayCoordinator], SwitchEntity):
    """Representation of one relay."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: RelayCoordinator, entry: ConfigEntry, relay_index: int) -> None:
        super().__init__(coordinator, context=relay_index)
        base_name = entry.data[CONF_NAME]
        self._relay_index = relay_index
        self._attr_name = f"Relay {relay_index + 1}"
        self._attr_unique_id = f"{entry.entry_id}_relay_{relay_index + 1}"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": base_name,
            "manufacturer": "Sealevel / Waveshare-compatible",
            "model": "PoE Modbus Relay",
        }

    @property
    def is_on(self) -> bool | None:
        if self.coordinator.data is None:
            return None
        if self._relay_index >= len(self.coordinator.data):
            return None
        return self.coordinator.data[self._relay_index]

    async def async_turn_on(self, **kwargs) -> None:
        await self.coordinator.async_set_relay(self._relay_index, True)

    async def async_turn_off(self, **kwargs) -> None:
        await self.coordinator.async_set_relay(self._relay_index, False)
