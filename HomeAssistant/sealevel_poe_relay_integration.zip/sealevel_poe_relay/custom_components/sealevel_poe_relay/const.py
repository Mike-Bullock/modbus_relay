"""Constants for Sealevel PoE Relay."""
from __future__ import annotations

from datetime import timedelta

DOMAIN = "sealevel_poe_relay"
PLATFORMS = ["switch"]

CONF_HOST = "host"
CONF_NAME = "name"
CONF_RELAY_COUNT = "relay_count"
CONF_SCAN_TIMEOUT = "scan_timeout"
CONF_TCP_PORT = "tcp_port"
CONF_DISCOVERY_PORT = "discovery_port"
CONF_UNIT_ID = "unit_id"
CONF_POLL_INTERVAL = "poll_interval"

DEFAULT_NAME = "PoE Relay"
DEFAULT_RELAY_COUNT = 8
DEFAULT_SCAN_TIMEOUT = 2.0
DEFAULT_TCP_PORT = 4196
DEFAULT_DISCOVERY_PORT = 1092
DEFAULT_UNIT_ID = 1
DEFAULT_POLL_INTERVAL = 10

MIN_RELAYS = 1
MAX_RELAYS = 32

COORDINATOR_UPDATE_INTERVAL = timedelta(seconds=DEFAULT_POLL_INTERVAL)

DISCOVERY_PAYLOAD = (
    b"ZL\x00\x00\xe4D\xca\x00\xc8\x0cMu\xd8\x0cMuU|\xe8+\xa4Cu\x04"
    b"\xc8\x0cMu\xd8\x0cMu\xf0\xe8\x19\x00\xd4\xa3?u\xdb\xa3?u\xb5\xaf"
    b"\xabI\x00\xe9\x19\x00\xd4\xa3?u\xdb\xa3?uE\xae\xabI@\x00\x00\x00"
    b"\x08\x00\x00\x00h\xe9\x19\x00)\x81@u\xc8\x0cMu\xd8\xe8\x19\x00"
    b"\xf4\xea\x19\x00)\x81@u\xff\xff\xff\xff\xdb\xa3?u.\xa3?u\xe0@\xca"
    b"\x00h\xe9\x19\x00\xd8\x0cMuTCu\x04\x18\xebLu\xe0@\xca\x00\x08\x00"
    b"\x00\x00\x0b\x00\x00\x00h\xe9\x19\x00P\xe9\x19\x00\xc2\xa4?u\xd8"
    b"\x0cMuh\xe9\x19\x00&R\xca\x00\xe5\x90?urN"
)
