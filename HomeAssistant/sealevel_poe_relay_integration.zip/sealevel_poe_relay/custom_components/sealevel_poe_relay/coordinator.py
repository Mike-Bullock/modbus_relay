"""Coordinator for relay polling."""
from __future__ import annotations

from datetime import timedelta
import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import (
    CONF_HOST,
    CONF_POLL_INTERVAL,
    CONF_RELAY_COUNT,
    CONF_TCP_PORT,
    CONF_UNIT_ID,
    DEFAULT_POLL_INTERVAL,
)
from .relay_client import RelayClient, RelayClientError

_LOGGER = logging.getLogger(__name__)


class RelayCoordinator(DataUpdateCoordinator[list[bool]]):
    """Coordinator for reading relay states."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        self.entry = entry
        host = entry.options.get(CONF_HOST, entry.data[CONF_HOST])
        self.client = RelayClient(
            host=host,
            port=entry.data[CONF_TCP_PORT],
            unit_id=entry.data[CONF_UNIT_ID],
        )
        self.relay_count = entry.options.get(CONF_RELAY_COUNT, entry.data[CONF_RELAY_COUNT])
        interval = entry.options.get(CONF_POLL_INTERVAL, entry.data.get(CONF_POLL_INTERVAL, DEFAULT_POLL_INTERVAL))
        super().__init__(
            hass,
            _LOGGER,
            name=f"{entry.title} relay coordinator",
            config_entry=entry,
            update_interval=timedelta(seconds=interval),
            always_update=False,
        )

    async def _async_update_data(self) -> list[bool]:
        try:
            return await self.client.async_read_relays(self.relay_count)
        except RelayClientError as err:
            raise UpdateFailed(str(err)) from err

    async def async_set_relay(self, relay_index: int, state: bool) -> None:
        if state:
            await self.client.async_turn_on(relay_index)
        else:
            await self.client.async_turn_off(relay_index)

        if self.data and relay_index < len(self.data):
            new_data = list(self.data)
            new_data[relay_index] = state
            self.async_set_updated_data(new_data)
        else:
            await self.async_request_refresh()
