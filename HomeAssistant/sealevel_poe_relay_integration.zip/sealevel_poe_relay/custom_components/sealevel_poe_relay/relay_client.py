"""TCP client for the PoE relay board."""
from __future__ import annotations

import asyncio
import logging
import socket
import struct
from typing import Final

_LOGGER = logging.getLogger(__name__)

RELAY_ON: Final[int] = 0xFF
RELAY_OFF: Final[int] = 0x00
RELAY_FLIP: Final[int] = 0x55


class RelayClientError(Exception):
    """Base relay client error."""


class RelayClient:
    """Low-level client for the relay board."""

    def __init__(self, host: str, port: int, unit_id: int = 1, timeout: float = 1.5) -> None:
        self._host = host
        self._port = port
        self._unit_id = unit_id
        self._timeout = timeout
        self._lock = asyncio.Lock()

    @property
    def host(self) -> str:
        return self._host

    def set_host(self, host: str) -> None:
        self._host = host

    async def async_turn_on(self, relay_index: int) -> None:
        await self._async_write_single_coil(relay_index, RELAY_ON)

    async def async_turn_off(self, relay_index: int) -> None:
        await self._async_write_single_coil(relay_index, RELAY_OFF)

    async def async_read_relays(self, relay_count: int) -> list[bool]:
        """Read current relay states.

        Assumes the board accepts RTU-style Modbus frames over its TCP socket.
        """
        quantity = max(1, relay_count)
        request = bytes(
            [
                self._unit_id,
                0x01,
                0x00,
                0x00,
                (quantity >> 8) & 0xFF,
                quantity & 0xFF,
            ]
        )
        response = await self._async_send_message(request)

        if len(response) < 5:
            raise RelayClientError(f"Response too short: {response!r}")
        if response[0] != self._unit_id or response[1] != 0x01:
            raise RelayClientError(f"Unexpected read response: {response!r}")

        byte_count = response[2]
        data = response[3 : 3 + byte_count]
        states: list[bool] = []
        for relay_index in range(quantity):
            byte_idx = relay_index // 8
            bit_idx = relay_index % 8
            if byte_idx >= len(data):
                states.append(False)
            else:
                states.append(bool((data[byte_idx] >> bit_idx) & 0x01))
        return states

    async def async_get_sw_version(self) -> str | None:
        request = bytes([self._unit_id, 0x03, 0x80, 0x00, 0x00, 0x01])
        response = await self._async_send_message(request)
        if len(response) < 5 or response[0] != self._unit_id or response[1] != 0x03:
            return None
        data_len = response[2]
        data = response[3 : 3 + data_len]
        return data.hex().upper() if data else None

    async def _async_write_single_coil(self, relay_index: int, action: int) -> None:
        request = bytes([self._unit_id, 0x05, 0x00, relay_index, action, 0x00])
        response = await self._async_send_message(request)
        if response[:6] != request:
            raise RelayClientError(f"Unexpected write response: {response!r}")

    async def _async_send_message(self, payload: bytes) -> bytes:
        async with self._lock:
            return await asyncio.to_thread(self._send_message_sync, payload)

    def _send_message_sync(self, payload: bytes) -> bytes:
        frame = payload + struct.pack("<H", self._crc16_modbus(payload))

        with socket.create_connection((self._host, self._port), timeout=self._timeout) as sock:
            sock.settimeout(self._timeout)
            sock.sendall(frame)

            read_buffer = bytearray()
            while True:
                chunk = sock.recv(1)
                if not chunk:
                    raise RelayClientError("Connection closed before reply was complete")
                read_buffer.extend(chunk)
                if self._crc16_modbus(bytes(read_buffer)) == 0:
                    return bytes(read_buffer)

    @staticmethod
    def _crc16_modbus(data: bytes) -> int:
        crc = 0xFFFF
        for value in data:
            crc ^= value
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return crc & 0xFFFF
